/*
Assignment no.2 First Unique Character in a String

Given a string s, find the first non-repeating character in it and return its index. If it does not exist, return -1.

*************please find below output of source code**************
 */


package assignment2;

import java.util.HashMap;

public class FirstUniqueCharacter {
    public static int firstUniqChar(String s) {
        // Create a hashmap to store the frequency of each character
        HashMap<Character, Integer> freqMap = new HashMap<>();

        // Build the frequency map
        for (char c : s.toCharArray()) {
            freqMap.put(c, freqMap.getOrDefault(c, 0) + 1);
        }

        // Iterate through the string to find the first unique character
        for (int i = 0; i < s.length(); i++) {
            if (freqMap.get(s.charAt(i)) == 1) {
                return i;
            }
        }

        return -1; // Return -1 if no unique character is found
    }

    public static void main(String[] args) {
        String s1 = "leetcode";
        System.out.println("Input: " + s1);
        System.out.println("Output: " + firstUniqChar(s1));

        String s2 = "loveleetcode";
        System.out.println("Input: " + s2);
        System.out.println("Output: " + firstUniqChar(s2));

        String s3 = "aabb";
        System.out.println("Input: " + s3);
        System.out.println("Output: " + firstUniqChar(s3));
    }
}



/*
************OutPut***********
Input: leetcode
Output: 0
Input: loveleetcode
Output: 2
Input: aabb
Output: -1


 */
